# Palletizer — Construction Vertical + ROS 2 / LiDAR Reference

Strictly additive. No existing core module, page, API, or the Vercel deploy is
rewritten. New Python packages, four new website routes, ROS 2 / LiDAR reference
code, packaging, and tests only.

## Apply (primary path — one command)

From the root of your cloned `palletizer` repo, on a clean working tree:

    git am < 0001-construction-vertical-ros2-lidar-reference.patch

That's it. Then verify:

    pip install -e ".[construction]" --break-system-packages && pytest tests/ -q
    cd web && npm install && npm run build

## Apply (fallback — only if git am conflicts)

If your `pyproject.toml`, `Navbar.tsx`, or `CHANGELOG.md` have diverged and
`git am` refuses, run `git am --abort`, then:

    bash apply-fallback.sh        # from the repo root

The `payload/` directory contains the exact final files (the three modified files
are included in full), so copying them over resolves everything.

## Verified before shipping (on a fresh clone + this patch)

- `git am` applies cleanly.
- Python: 75 tests pass (70 existing + 5 new). `palletize-construction --demo-drywall` runs.
- Web: `npm run build` is green; `/construction`, `/hardware`, `/integrations`,
  `/about` all prerender.
- `construction/` imports cleanly (the incoming pack had two circular imports — fixed).
- `ros2_integration` imports without ROS 2 installed (rclpy loads lazily).

## What changed vs. the pack you handed me

The engineering was solid; the integration wasn't wired to this repo, and the copy
overclaimed. Fixed before merge:

- **Two circular imports** in `construction/` (it could not be imported at all).
- **Broken packaging**: the pack assumed poetry (repo is setuptools), rewrote
  `pyproject.toml` with `toml.dump` (dropping comments), never added the new
  packages to the find-include (so console scripts would break), and told you to
  `pip install` ROS extras (`rclpy`/`sensor-msgs`/`open3d`) that fail outside a ROS
  workspace. Replaced with a clean, pip-installable `construction` extra.
- **Duplicate navigation**: each new page shipped its own `<nav>`/footer, which
  would double up with the global `Navbar`/`Footer`. Removed; pages reuse the shell.
- **Wrong import path** for the browser engine (`../../../lib/...` → `@/lib/...`).
- **Fabricated / unverifiable claims** removed everywhere: "8–14 month payback",
  "18%+ density uplift", "60%+ injury reduction", "+18% vs manual", "certified /
  production-proven", "ISO 10218 / TS 15066 ready", OEM-partner implications,
  "we are hiring", "full software + hardware company". Replaced with honest
  pre-launch, open-core, reference-architecture, seeking-pilot copy.

## One straight thought

None of this is the bottleneck, and you already know it — you've said as much on
the other builds. The engine, the demo, the pages: all real now, all honest. The
thing that moves this from a good repo to a company is one construction-products
line or prefab yard that agrees to a pilot. That's a conversation, not a commit.
