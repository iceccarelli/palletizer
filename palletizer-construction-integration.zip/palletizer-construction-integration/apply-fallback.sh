#!/usr/bin/env bash
# Fallback applier — use ONLY if `git am` reported a conflict.
# Run from the ROOT of your cloned palletizer repo:
#   bash /path/to/apply-fallback.sh
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ ! -f "pyproject.toml" ] || [ ! -d "web/app" ]; then
  echo "ERROR: run this from the repo root (where pyproject.toml and web/ live)." >&2
  exit 1
fi
echo "Copying construction integration files into the repo…"
cp -r "$HERE/payload/." .
echo "Done. New routes: /construction /hardware /integrations /about"
echo "Verify:"
echo "  pip install -e \".[construction]\" --break-system-packages && pytest tests/ -q"
echo "  cd web && npm install && npm run build"
